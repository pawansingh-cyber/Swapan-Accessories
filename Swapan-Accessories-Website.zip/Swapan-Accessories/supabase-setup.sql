-- Run this in Supabase Dashboard > SQL Editor.
-- Create a private admin user first in Authentication > Users.
-- Then copy that user's UUID into the INSERT at the bottom.
-- Never expose a service_role/secret key in website files.

create extension if not exists pgcrypto;

create table if not exists public.products (
  id uuid primary key default gen_random_uuid(),
  name text not null check (char_length(name) between 1 and 100),
  price numeric(10,2) not null default 0 check (price >= 0),
  category text not null default 'Earrings',
  description text not null default '',
  image_url text,
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.store_admins (
  user_id uuid primary key references auth.users(id) on delete cascade,
  created_at timestamptz not null default now()
);

alter table public.products enable row level security;
alter table public.store_admins enable row level security;

-- Public customers can only read products explicitly marked visible.
drop policy if exists "Public can view active products" on public.products;
create policy "Public can view active products"
on public.products for select
to anon, authenticated
using (is_active = true or exists (
  select 1 from public.store_admins where user_id = (select auth.uid())
));

-- Only the explicitly listed admin account can add, edit or delete products.
drop policy if exists "Admins can insert products" on public.products;
create policy "Admins can insert products"
on public.products for insert to authenticated
with check (exists (select 1 from public.store_admins where user_id = (select auth.uid())));

drop policy if exists "Admins can update products" on public.products;
create policy "Admins can update products"
on public.products for update to authenticated
using (exists (select 1 from public.store_admins where user_id = (select auth.uid())))
with check (exists (select 1 from public.store_admins where user_id = (select auth.uid())));

drop policy if exists "Admins can delete products" on public.products;
create policy "Admins can delete products"
on public.products for delete to authenticated
using (exists (select 1 from public.store_admins where user_id = (select auth.uid())));

-- Admin allowlist table is not readable or writable from the browser.
revoke all on public.store_admins from anon, authenticated;
grant select, insert, update, delete on public.products to anon, authenticated;

-- Product photos are served publicly, but only store admins can upload/delete them.
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('product-images', 'product-images', true, 5242880, array['image/jpeg','image/png','image/webp'])
on conflict (id) do update set public = true, file_size_limit = 5242880,
  allowed_mime_types = array['image/jpeg','image/png','image/webp'];

drop policy if exists "Public can view product images" on storage.objects;
create policy "Public can view product images"
on storage.objects for select to anon, authenticated
using (bucket_id = 'product-images');

drop policy if exists "Admins can upload product images" on storage.objects;
create policy "Admins can upload product images"
on storage.objects for insert to authenticated
with check (
  bucket_id = 'product-images' and
  exists (select 1 from public.store_admins where user_id = (select auth.uid()))
);

drop policy if exists "Admins can update product images" on storage.objects;
create policy "Admins can update product images"
on storage.objects for update to authenticated
using (
  bucket_id = 'product-images' and
  exists (select 1 from public.store_admins where user_id = (select auth.uid()))
)
with check (
  bucket_id = 'product-images' and
  exists (select 1 from public.store_admins where user_id = (select auth.uid()))
);

drop policy if exists "Admins can delete product images" on storage.objects;
create policy "Admins can delete product images"
on storage.objects for delete to authenticated
using (
  bucket_id = 'product-images' and
  exists (select 1 from public.store_admins where user_id = (select auth.uid()))
);

-- After creating the admin in Authentication > Users, replace the UUID below:
-- insert into public.store_admins (user_id) values ('PASTE-ADMIN-USER-UUID-HERE');
