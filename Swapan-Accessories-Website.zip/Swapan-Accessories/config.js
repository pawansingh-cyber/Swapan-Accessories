/*
  SWAPAN ACCESSORIES SETTINGS
  1. Create a Supabase project and follow README.md.
  2. Replace the Supabase URL and anon/publishable key below.
  3. Enter your WhatsApp number with country code, digits only (India: 91...).
  4. Replace the Instagram and YouTube URLs with your real profile/channel links.
  Never put a Supabase service_role/secret key in this file.
*/
window.SWAPAN_CONFIG = {
  supabaseUrl: "YOUR_SUPABASE_PROJECT_URL",
  supabaseAnonKey: "YOUR_SUPABASE_ANON_OR_PUBLISHABLE_KEY",
  whatsappNumber: "91YOURNUMBER",
  instagramUrl: "https://www.instagram.com/YOUR_USERNAME/",
  youtubeUrl: "https://www.youtube.com/@YOUR_CHANNEL"
};
