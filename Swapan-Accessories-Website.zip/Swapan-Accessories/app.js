(() => {
  "use strict";
  const config = window.SWAPAN_CONFIG || {};
  const configured = config.supabaseUrl && !config.supabaseUrl.includes("YOUR_") &&
    config.supabaseAnonKey && !config.supabaseAnonKey.includes("YOUR_") &&
    window.supabase;
  const client = configured ? window.supabase.createClient(config.supabaseUrl, config.supabaseAnonKey) : null;
  const $ = (id) => document.getElementById(id);
  let products = [];
  let category = "All";
  let editingProduct = null;

  $("year").textContent = new Date().getFullYear();

  function validSocialUrl(url, fallback) {
    try { const parsed = new URL(url); return ["https:", "http:"].includes(parsed.protocol) && !url.includes("YOUR_") ? url : fallback; }
    catch { return fallback; }
  }
  const waNumber = (config.whatsappNumber || "").replace(/\D/g, "");
  const waUrl = waNumber && !waNumber.includes("YOURNUMBER")
    ? `https://wa.me/${waNumber}?text=${encodeURIComponent("Hi Swapan Accessories! I'd like to know more about your jewellery.")}`
    : "https://wa.me/?text=" + encodeURIComponent("Hi Swapan Accessories! I'd like to know more about your jewellery.");
  $("headerWhatsApp").href = waUrl;
  $("whatsappLink").href = waUrl;
  $("instagramLink").href = validSocialUrl(config.instagramUrl, "https://www.instagram.com/");
  $("youtubeLink").href = validSocialUrl(config.youtubeUrl, "https://www.youtube.com/");
  $("instagramLink").setAttribute("aria-label", "Instagram (update your profile link in config.js)");
  $("youtubeLink").setAttribute("aria-label", "YouTube (update your channel link in config.js)");

  function money(value) {
    return new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR", maximumFractionDigits: 0 }).format(Number(value || 0));
  }
  function escapeHtml(value) {
    return String(value ?? "").replace(/[&<>"']/g, (char) => ({ "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;", "'":"&#39;" }[char]));
  }
  function orderUrl(product) {
    const text = `Hi Swapan Accessories! I'm interested in "${product.name}"${product.price != null ? ` (${money(product.price)})` : ""}. Please share details and availability.`;
    return waNumber && !waNumber.includes("YOURNUMBER")
      ? `https://wa.me/${waNumber}?text=${encodeURIComponent(text)}`
      : `https://wa.me/?text=${encodeURIComponent(text)}`;
  }
  function renderProducts() {
    const grid = $("productGrid");
    const visible = products.filter(p => p.is_active && (category === "All" || p.category === category));
    grid.innerHTML = "";
    $("emptyState").classList.toggle("hidden", visible.length > 0);
    if (!client) {
      grid.innerHTML = `<div class="setup-notice"><span>✧</span><h3>Your jewellery collection is on its way.</h3><p>Connect your Supabase project in <code>config.js</code> to load products and enable image uploads. Setup steps are in README.md.</p></div>`;
      return;
    }
    if (!visible.length) return;
    visible.forEach((p, i) => {
      const card = document.createElement("article");
      card.className = "product-card";
      card.style.animationDelay = `${Math.min(i * 50, 300)}ms`;
      const photo = p.image_url
        ? `<img src="${escapeHtml(p.image_url)}" alt="${escapeHtml(p.name)}" loading="lazy">`
        : `<div class="product-placeholder"><span>SA</span><small>SWAPAN ACCESSORIES</small></div>`;
      card.innerHTML = `<div class="product-photo">${photo}<span class="product-category">${escapeHtml(p.category || "Jewellery")}</span></div><div class="product-info"><div><h3>${escapeHtml(p.name)}</h3><p>${escapeHtml(p.description || "A lovely addition to your collection.")}</p></div><div class="product-bottom"><strong>${money(p.price)}</strong><a class="order-button" href="${orderUrl(p)}" target="_blank" rel="noopener">Enquire <span>↗</span></a></div></div>`;
      grid.appendChild(card);
    });
  }
  async function loadProducts() {
    if (!client) { renderProducts(); return; }
    const { data, error } = await client.from("products").select("*").eq("is_active", true).order("created_at", { ascending: false });
    if (error) {
      $("productGrid").innerHTML = `<div class="setup-notice"><h3>We’re getting the collection ready.</h3><p>Product loading failed. Check your Supabase setup and database policies in README.md.</p></div>`;
      console.error(error);
      return;
    }
    products = data || [];
    renderProducts();
    if (client.auth) {
      const { data: { session } } = await client.auth.getSession();
      if (session) showDashboard();
    }
  }
  $("filters").addEventListener("click", (event) => {
    const button = event.target.closest("[data-category]");
    if (!button) return;
    category = button.dataset.category;
    document.querySelectorAll(".filter").forEach(b => b.classList.toggle("active", b === button));
    renderProducts();
  });

  function showAdmin() { $("adminBackdrop").classList.remove("hidden"); document.body.classList.add("modal-open"); }
  function hideAdmin() { $("adminBackdrop").classList.add("hidden"); document.body.classList.remove("modal-open"); }
  function showDashboard() {
    $("adminLoginView").classList.add("hidden");
    $("adminDashboard").classList.remove("hidden");
    loadAdminProducts();
  }
  function showLogin() {
    $("adminLoginView").classList.remove("hidden");
    $("adminDashboard").classList.add("hidden");
  }
  $("adminToggle").addEventListener("click", () => {
    showAdmin();
    if (!client) $("loginMessage").textContent = "Setup needed: add your Supabase URL and public key in config.js first.";
  });
  $("closeAdmin").addEventListener("click", hideAdmin);
  $("adminBackdrop").addEventListener("click", (e) => { if (e.target === $("adminBackdrop")) hideAdmin(); });
  document.addEventListener("keydown", (e) => { if (e.key === "Escape") hideAdmin(); });

  $("loginForm").addEventListener("submit", async (event) => {
    event.preventDefault();
    if (!client) { $("loginMessage").textContent = "Please complete the Supabase setup first."; return; }
    $("loginMessage").textContent = "Signing in…";
    const { error } = await client.auth.signInWithPassword({
      email: $("adminEmail").value.trim(),
      password: $("adminPassword").value
    });
    if (error) { $("loginMessage").textContent = error.message; return; }
    $("loginMessage").textContent = "";
    showDashboard();
  });
  $("logoutButton").addEventListener("click", async () => {
    await client.auth.signOut();
    showLogin();
    resetProductForm();
    $("loginMessage").textContent = "You have signed out.";
  });

  function resetProductForm() {
    $("productForm").reset();
    $("productId").value = "";
    $("productActive").checked = true;
    editingProduct = null;
    $("saveProductButton").textContent = "Save product";
    $("cancelEditButton").classList.add("hidden");
    $("productMessage").textContent = "";
  }
  $("cancelEditButton").addEventListener("click", resetProductForm);

  $("productForm").addEventListener("submit", async (event) => {
    event.preventDefault();
    if (!client) return;
    const button = $("saveProductButton");
    button.disabled = true;
    $("productMessage").textContent = "Saving product…";
    let imageUrl = editingProduct?.image_url || null;
    const file = $("productImage").files[0];
    try {
      if (file) {
        if (file.size > 5 * 1024 * 1024) throw new Error("Please choose an image smaller than 5 MB.");
        if (!["image/jpeg", "image/png", "image/webp"].includes(file.type)) throw new Error("Please use a JPG, PNG or WebP image.");
        const safeName = file.name.toLowerCase().replace(/[^a-z0-9._-]/g, "-");
        const path = `${crypto.randomUUID()}-${safeName}`;
        const { error: uploadError } = await client.storage.from("product-images").upload(path, file, { cacheControl: "3600", upsert: false, contentType: file.type });
        if (uploadError) throw uploadError;
        const { data: urlData } = client.storage.from("product-images").getPublicUrl(path);
        imageUrl = urlData.publicUrl;
      }
      const record = {
        name: $("productName").value.trim(),
        price: Number($("productPrice").value),
        category: $("productCategory").value,
        description: $("productDescription").value.trim(),
        image_url: imageUrl,
        is_active: $("productActive").checked
      };
      if (!record.name) throw new Error("Enter a product name.");
      let result;
      if (editingProduct) {
        result = await client.from("products").update(record).eq("id", editingProduct.id);
      } else {
        result = await client.from("products").insert(record);
      }
      if (result.error) throw result.error;
      $("productMessage").textContent = "Product saved successfully.";
      resetProductForm();
      await loadProducts();
      await loadAdminProducts();
    } catch (error) {
      $("productMessage").textContent = error.message || "Could not save product.";
    } finally {
      button.disabled = false;
    }
  });

  async function loadAdminProducts() {
    if (!client) return;
    const holder = $("adminProductList");
    holder.innerHTML = "<p>Loading products…</p>";
    const { data, error } = await client.from("products").select("*").order("created_at", { ascending: false });
    if (error) { holder.innerHTML = `<p class="form-message">${escapeHtml(error.message)}. Confirm this account is an admin in Supabase.</p>`; return; }
    if (!data?.length) { holder.innerHTML = "<p>No products yet. Add your first product above.</p>"; return; }
    holder.innerHTML = "";
    data.forEach((p) => {
      const row = document.createElement("div");
      row.className = "admin-product-row";
      row.innerHTML = `<div class="admin-thumb">${p.image_url ? `<img src="${escapeHtml(p.image_url)}" alt="">` : "SA"}</div><div class="admin-product-copy"><strong>${escapeHtml(p.name)}</strong><small>${money(p.price)} · ${escapeHtml(p.category)} · ${p.is_active ? "Visible" : "Hidden"}</small></div><button class="mini-button edit-product" type="button">Edit</button><button class="mini-button danger delete-product" type="button">Delete</button>`;
      row.querySelector(".edit-product").addEventListener("click", () => {
        editingProduct = p;
        $("productId").value = p.id;
        $("productName").value = p.name;
        $("productPrice").value = p.price;
        $("productCategory").value = p.category;
        $("productDescription").value = p.description || "";
        $("productActive").checked = p.is_active;
        $("productImage").value = "";
        $("saveProductButton").textContent = "Update product";
        $("cancelEditButton").classList.remove("hidden");
        $("productMessage").textContent = "Editing product. Select a new image only if you want to replace the current photo.";
        $("productForm").scrollIntoView({ behavior: "smooth", block: "start" });
      });
      row.querySelector(".delete-product").addEventListener("click", async () => {
        if (!confirm(`Delete "${p.name}"? This cannot be undone.`)) return;
        const { error: deleteError } = await client.from("products").delete().eq("id", p.id);
        if (deleteError) { alert(deleteError.message); return; }
        await loadProducts();
        await loadAdminProducts();
      });
      holder.appendChild(row);
    });
  }

  loadProducts();
})();
