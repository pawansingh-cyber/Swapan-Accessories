# Swapan Accessories website

A responsive jewellery catalogue for GitHub Pages with:
- Product gallery and category filters
- Private admin sign-in
- Add/edit/delete products and upload product photos
- Supabase database + image storage
- WhatsApp enquiry links for each product
- Instagram and YouTube profile links

## Important: what is included

The website code is ready, but it will not show real products or accept admin uploads until you connect your own Supabase project and update `config.js`. Your WhatsApp/social URLs also need your real links. Do not share passwords or secret keys.

## 1. Create the database and image storage

1. Go to https://supabase.com/ and create a project. Save the project password privately.
2. Open **SQL Editor** in the Supabase dashboard.
3. Open `supabase-setup.sql` from this folder, copy all of its contents, and run it.
4. Go to **Project Settings → API** (or the API Keys page). Copy the **Project URL** and the **publishable/anon key**. Never copy the `service_role` or secret key into this website.

## 2. Create your private admin login

1. In Supabase, open **Authentication → Users**.
2. Create/add a user with your email and a strong password. Disable public sign-ups if your project has them enabled; this site does not need customer accounts.
3. Copy that user's UUID from the Users list.
4. In **SQL Editor**, run this statement after replacing the example UUID:
   ```sql
   insert into public.store_admins (user_id)
   values ('PASTE-ADMIN-USER-UUID-HERE');
   ```
5. The admin button is the small ✦ at the bottom-right of the website. Sign in using that email and password.

Only user IDs listed in `public.store_admins` can manage products and upload images. The public gallery shows active products only.

## 3. Add your website settings

Open `config.js` and replace the example values:

```js
window.SWAPAN_CONFIG = {
  supabaseUrl: "https://YOUR-PROJECT-REF.supabase.co",
  supabaseAnonKey: "YOUR_PUBLIC_PUBLISHABLE_OR_ANON_KEY",
  whatsappNumber: "919876543210",
  instagramUrl: "https://www.instagram.com/YOUR_USERNAME/",
  youtubeUrl: "https://www.youtube.com/@YOUR_CHANNEL"
};
```

- WhatsApp number: digits only, with country code. For India, start with `91`, without `+` or spaces.
- Instagram: your exact profile URL.
- YouTube: your exact channel URL.
- Use only the public anon/publishable key. Never use a Supabase service-role/secret key in `config.js`.

## 4. Publish using your existing GitHub repository

1. Open your repository: https://github.com/pawansingh-cyber/Swapan-Accessories
2. Download/extract this project ZIP on your computer.
3. Upload the project files and folders to the **root** of the repository. Ensure `index.html`, `config.js`, `app.js`, `styles.css`, and `supabase-setup.sql` are at the repository root, not inside an extra nested folder.
4. Commit the changes.
5. In GitHub, open **Settings → Pages**.
6. Under **Build and deployment**, choose **Deploy from a branch**, select `main` (or your default branch) and `/ (root)`, then Save.
7. Wait for GitHub Pages to publish. The public URL appears in the Pages settings. If you use a custom domain later, configure it there.

## 5. Add products

Open your published site and click the little ✦ at the bottom-right. Sign in, then enter product name, price, category, description and image. Tick “Show this product” to display it publicly. Customers can click **Enquire** to send a WhatsApp message about that specific product.

## Notes

- This is a catalogue with WhatsApp enquiries, not an online payment checkout.
- Product images are public because customers need to view them; the upload/edit/delete controls are protected by Supabase Auth and Row Level Security.
- Deleting a product removes its database record; its old image file may remain in storage. You can periodically clean up unused images in Supabase Storage.
- Test the admin sign-in and product upload after publishing. If you later connect a custom domain, add it under Supabase Authentication URL settings if required.
