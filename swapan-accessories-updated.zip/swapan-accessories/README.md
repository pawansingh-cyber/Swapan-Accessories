# Swapan Accessories

Responsive jewellery catalogue website built with React, Vite and optional Supabase backend.

See [SETUP.md](./SETUP.md) for local setup, admin login, image storage and free deployment instructions.
