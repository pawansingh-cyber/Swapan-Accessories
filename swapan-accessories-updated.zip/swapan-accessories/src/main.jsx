import React, { useEffect, useMemo, useState } from "react";
import { createRoot } from "react-dom/client";
import { createClient } from "@supabase/supabase-js";
import { Search, Gem, MessageCircle, Plus, Pencil, Trash2, X, Upload, ShieldCheck, Instagram, Youtube, Menu, Heart, ArrowUpRight } from "lucide-react";
import "./styles.css";

const SUPABASE_URL = import.meta.env.VITE_SUPABASE_URL || "";
const SUPABASE_ANON_KEY = import.meta.env.VITE_SUPABASE_ANON_KEY || "";
const supabase = SUPABASE_URL && SUPABASE_ANON_KEY ? createClient(SUPABASE_URL, SUPABASE_ANON_KEY) : null;

// EDIT THESE: your WhatsApp number (country code + number, no +, spaces or dashes)
// and your social media links.
const WHATSAPP_NUMBER = "919876543210";
const INSTAGRAM_URL = "https://instagram.com/your_username";
const YOUTUBE_URL = "https://youtube.com/@your_channel";
const STORE_NAME = "Swapan Accessories";

const demoProducts = [
  { id: "demo-1", name: "Golden Bloom Earrings", category: "Earrings", price: 499, code: "ER001", description: "A graceful pair for festive days and special occasions.", image_url: "https://images.unsplash.com/photo-1535632066927-ab7c9ab60908?auto=format&fit=crop&w=900&q=85", available: true },
  { id: "demo-2", name: "Everyday Gold Hoops", category: "Earrings", price: 349, code: "ER002", description: "Lightweight, versatile hoops for everyday styling.", image_url: "https://images.unsplash.com/photo-1630019852942-f89202989a59?auto=format&fit=crop&w=900&q=85", available: true },
  { id: "demo-3", name: "Classic Pendant Necklace", category: "Necklaces", price: 799, code: "NK001", description: "A delicate necklace that pairs beautifully with any look.", image_url: "https://images.unsplash.com/photo-1599643478518-a784e5dc4c8f?auto=format&fit=crop&w=900&q=85", available: true },
  { id: "demo-4", name: "Pearl Charm Necklace", category: "Necklaces", price: 649, code: "NK002", description: "A timeless style for gifting or your own collection.", image_url: "https://images.unsplash.com/photo-1611652022419-a9419f74343d?auto=format&fit=crop&w=900&q=85", available: true }
];

const money = value => new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR", maximumFractionDigits: 0 }).format(Number(value || 0));

function App() {
  const [products, setProducts] = useState(demoProducts);
  const [connected, setConnected] = useState(false);
  const [loading, setLoading] = useState(false);
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState("All");
  const [adminOpen, setAdminOpen] = useState(false);
  const [session, setSession] = useState(null);
  const [loginEmail, setLoginEmail] = useState("");
  const [loginPassword, setLoginPassword] = useState("");
  const [loginMessage, setLoginMessage] = useState("");
  const [editing, setEditing] = useState(null);
  const [mobileMenu, setMobileMenu] = useState(false);
  const [favorites, setFavorites] = useState([]);

  useEffect(() => {
    if (!supabase) return;
    setConnected(true);
    supabase.auth.getSession().then(({ data }) => setSession(data.session));
    const { data: listener } = supabase.auth.onAuthStateChange((_event, nextSession) => setSession(nextSession));
    loadProducts();
    return () => listener.subscription.unsubscribe();
  }, []);

  async function loadProducts() {
    if (!supabase) return;
    setLoading(true);
    const { data, error } = await supabase.from("products").select("*").order("created_at", { ascending: false });
    if (!error && data) setProducts(data);
    setLoading(false);
  }

  const filtered = useMemo(() => products.filter(p => {
    const matchesCategory = category === "All" || p.category === category;
    const term = search.trim().toLowerCase();
    const matchesSearch = !term || [p.name, p.code, p.category, p.description].some(v => String(v || "").toLowerCase().includes(term));
    return matchesCategory && matchesSearch;
  }), [products, category, search]);

  function enquiry(product) {
    const text = `Hello ${STORE_NAME}! I'm interested in ${product.name} (${product.code || "no product code"}) priced at ${money(product.price)}. Is it available?`;
    if (!WHATSAPP_NUMBER) {
      navigator.clipboard?.writeText(text).then(() => alert("Enquiry text copied. Add your WhatsApp number in src/main.jsx to open WhatsApp directly."));
      return;
    }
    window.open(`https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(text)}`, "_blank", "noopener,noreferrer");
  }

  async function login(e) {
    e.preventDefault();
    setLoginMessage("");
    if (!supabase) {
      setLoginMessage("Connect Supabase first. Follow SETUP.md in the project folder.");
      return;
    }
    const { error } = await supabase.auth.signInWithPassword({ email: loginEmail, password: loginPassword });
    setLoginMessage(error ? error.message : "Signed in.");
  }

  async function signOut() {
    if (supabase) await supabase.auth.signOut();
    setSession(null);
  }

  async function saveProduct(e) {
    e.preventDefault();
    if (!supabase || !session) return alert("Please sign in to the admin panel first.");
    const form = new FormData(e.currentTarget);
    const file = form.get("photo");
    let image_url = editing?.image_url || "";
    if (file && file.size) {
      const safeName = `${Date.now()}-${file.name.replace(/[^a-zA-Z0-9._-]/g, "-")}`;
      const { error: uploadError } = await supabase.storage.from("product-images").upload(safeName, file, { upsert: false });
      if (uploadError) return alert(`Photo upload failed: ${uploadError.message}`);
      image_url = supabase.storage.from("product-images").getPublicUrl(safeName).data.publicUrl;
    }
    const item = {
      name: String(form.get("name") || "").trim(),
      category: String(form.get("category") || "Earrings"),
      price: Number(form.get("price") || 0),
      code: String(form.get("code") || "").trim(),
      description: String(form.get("description") || "").trim(),
      image_url,
      available: form.get("available") === "on"
    };
    if (!item.name || item.price < 0 || !item.image_url) return alert("Enter a product name, valid price, and upload a photo.");
    const result = editing?.id
      ? await supabase.from("products").update(item).eq("id", editing.id).select().single()
      : await supabase.from("products").insert(item).select().single();
    if (result.error) return alert(`Could not save product: ${result.error.message}`);
    setProducts(old => editing?.id ? old.map(p => p.id === editing.id ? result.data : p) : [result.data, ...old]);
    setEditing(null);
  }

  async function deleteProduct(product) {
    if (!supabase || !session) return;
    if (!window.confirm(`Delete "${product.name}"? This cannot be undone.`)) return;
    const { error } = await supabase.from("products").delete().eq("id", product.id);
    if (error) return alert(error.message);
    setProducts(old => old.filter(p => p.id !== product.id));
  }

  return <div className="app">
    <div className="announcement">A little sparkle, a lot of style <span>✦</span> Discover your next favourite</div>
    <header className="header">
      <a className="brand" href="#" aria-label="Swapan Accessories home">
        <span className="brand-icon"><Gem size={25} strokeWidth={1.4}/></span>
        <span><strong>SWAPAN</strong><small>ACCESSORIES</small></span>
      </a>
      <nav className={mobileMenu ? "nav open" : "nav"}>
        <a href="#collection" onClick={() => setCategory("All")}>Shop all</a>
        <a href="#collection" onClick={() => setCategory("Earrings")}>Earrings</a>
        <a href="#collection" onClick={() => setCategory("Necklaces")}>Necklaces</a>
        <a href="#about">Our story</a>
      </nav>
      <div className="header-actions">
        <button className="icon-button" aria-label="Search products" onClick={() => document.getElementById("search-box")?.focus()}><Search size={20}/></button>
        <button className="icon-button admin-shortcut" aria-label="Admin login" onClick={() => setAdminOpen(true)}><ShieldCheck size={20}/></button>
        <button className="icon-button mobile-toggle" aria-label="Toggle menu" onClick={() => setMobileMenu(v => !v)}><Menu size={22}/></button>
      </div>
    </header>

    {!connected && <div className="setup-banner"><strong>Preview mode:</strong> This website is showing sample products. Follow <code>SETUP.md</code> to connect your database and enable real uploads.</div>}

    <main>
      <section className="hero">
        <div className="hero-copy">
          <p className="eyebrow"><span className="tiny-star">✦</span> THE LITTLE THINGS THAT SHINE</p>
          <h1>Made to make<br/><em>you sparkle.</em></h1>
          <p className="hero-text">Jewellery and accessories that bring a little extra magic to every moment. Find a piece that feels like you.</p>
          <a className="primary-button" href="#collection">Explore collection <ArrowUpRight size={17}/></a>
          <div className="hero-note"><span className="note-line"></span> Thoughtfully picked. Beautifully worn.</div>
        </div>
        <div className="hero-visual">
          <img className="hero-image" src="https://images.unsplash.com/photo-1617038220319-276d3cfab638?auto=format&fit=crop&w=1300&q=90" alt="Elegant gold jewellery on a neutral background"/>
          <div className="floating-note"><span className="floating-gem"><Gem size={21}/></span><span><strong>A little luxury</strong><small>for every day</small></span></div>
          <span className="hero-orbit orbit-one"></span><span className="hero-orbit orbit-two"></span>
        </div>
        <div className="hero-stamp">STYLE<br/>WITH<br/>SOUL</div>
      </section>

      <section className="benefits">
        <div><Gem size={19}/><span>Handpicked styles</span></div>
        <div><Heart size={19}/><span>Made for gifting</span></div>
        <div><MessageCircle size={19}/><span>Easy WhatsApp enquiries</span></div>
      </section>

      <section id="collection" className="collection section-wrap">
        <div className="section-heading">
          <div><p className="eyebrow">YOUR NEXT FAVOURITE PIECE</p><h2>The collection<span>.</span></h2><p className="section-subtitle">Little treasures. Big feelings.</p></div>
          <label className="search-field"><Search size={18}/><input id="search-box" value={search} onChange={e => setSearch(e.target.value)} placeholder="Search jewellery..." /></label>
        </div>
        <div className="filters">
          {["All", "Earrings", "Necklaces", "Other"].map(c => <button key={c} className={category === c ? "filter active" : "filter"} onClick={() => setCategory(c)}>{c}</button>)}
          <span className="result-count">{loading ? "Loading..." : `${filtered.length} ${filtered.length === 1 ? "piece" : "pieces"}`}</span>
        </div>
        <div className="product-grid">
          {filtered.map((p, i) => <article className="product-card" key={p.id}>
            <div className="product-image-wrap">
              <img src={p.image_url || "https://placehold.co/700x850/f4eee5/94784d?text=Swapan+Accessories"} alt={p.name} loading={i > 1 ? "lazy" : "eager"}/>
              {!p.available && <span className="sold-out">Currently unavailable</span>}
              <button className={favorites.includes(p.id) ? "favourite liked" : "favourite"} aria-label="Save favourite" onClick={() => setFavorites(old => old.includes(p.id) ? old.filter(id => id !== p.id) : [...old, p.id])}><Heart size={18} fill={favorites.includes(p.id) ? "currentColor" : "none"}/></button>
              <span className="product-category">{p.category}</span>
            </div>
            <div className="product-info">
              <div className="product-title-line"><h3>{p.name}</h3><span className="price">{money(p.price)}</span></div>
              <p>{p.description || "A beautiful addition to your collection."}</p>
              <div className="product-bottom"><span className="product-code">{p.code || "SWAPAN"}</span><button className="enquire-button" disabled={!p.available} onClick={() => enquiry(p)}><MessageCircle size={16}/> Enquire <ArrowUpRight size={14}/></button></div>
            </div>
            {session && <div className="admin-card-actions"><button onClick={() => { setEditing(p); setAdminOpen(true); }}><Pencil size={14}/> Edit</button><button onClick={() => deleteProduct(p)}><Trash2 size={14}/> Delete</button></div>}
          </article>)}
          {!filtered.length && <div className="empty-state"><Gem size={28}/><h3>No pieces found</h3><p>Try another search or category.</p><button className="text-button" onClick={() => { setSearch(""); setCategory("All"); }}>Clear filters</button></div>}
        </div>
      </section>

      <section className="story" id="about">
        <div className="story-mark"><Gem size={34} strokeWidth={1.2}/><span>SA</span></div>
        <div><p className="eyebrow">A NOTE FROM US</p><h2>Little details.<br/><em>Lasting impressions.</em></h2><p>At Swapan Accessories, we believe the right piece can make an ordinary day feel special. Explore the collection and message us if something catches your eye.</p></div>
      </section>

      <section className="contact-strip">
        <div><p className="eyebrow">FOUND SOMETHING YOU LOVE?</p><h2>Let's make it yours.</h2><p>Questions about a piece? We'd love to hear from you.</p></div>
        <button className="primary-button" onClick={() => {
          const message = `Hello ${STORE_NAME}! I'd like to know more about your collection.`;
          if (WHATSAPP_NUMBER) window.open(`https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(message)}`, "_blank", "noopener,noreferrer");
          else { navigator.clipboard?.writeText(message); alert("Add your WhatsApp number in src/main.jsx to enable direct WhatsApp chat."); }
        }}><MessageCircle size={17}/> Contact us</button>
      </section>
    </main>

    <footer className="footer"><a className="brand footer-brand" href="#"><span className="brand-icon"><Gem size={23}/></span><span><strong>SWAPAN</strong><small>ACCESSORIES</small></span></a><p>Find your sparkle, every day.</p><div className="footer-links"><a href="#collection">Collection</a><a href="#about">Our story</a><button onClick={() => setAdminOpen(true)}>Admin</button></div><div className="social-links"><a href={`https://wa.me/${WHATSAPP_NUMBER}`} target="_blank" rel="noopener noreferrer" aria-label="WhatsApp"><MessageCircle size={20}/></a><a href={INSTAGRAM_URL} target="_blank" rel="noopener noreferrer" aria-label="Instagram"><Instagram size={20}/></a><a href={YOUTUBE_URL} target="_blank" rel="noopener noreferrer" aria-label="YouTube"><Youtube size={20}/></a></div><small>© {new Date().getFullYear()} Swapan Accessories. All rights reserved.</small></footer>

    {adminOpen && <div className="modal-backdrop" onMouseDown={e => { if (e.target === e.currentTarget) { setAdminOpen(false); setEditing(null); } }}>
      <section className="admin-modal" role="dialog" aria-modal="true" aria-labelledby="admin-title">
        <button className="modal-close" aria-label="Close admin" onClick={() => { setAdminOpen(false); setEditing(null); }}><X size={20}/></button>
        {!session ? <>
          <div className="modal-icon"><ShieldCheck size={24}/></div><p className="eyebrow">STORE OWNER ACCESS</p><h2 id="admin-title">Admin login</h2><p className="modal-description">Sign in to add products, update prices and manage your collection.</p>
          <form className="admin-form" onSubmit={login}><label>Email address<input type="email" value={loginEmail} onChange={e => setLoginEmail(e.target.value)} required placeholder="you@example.com"/></label><label>Password<input type="password" value={loginPassword} onChange={e => setLoginPassword(e.target.value)} required placeholder="Your password"/></label><button className="primary-button full-button" type="submit">Sign in securely</button></form>
          {loginMessage && <p className="form-message">{loginMessage}</p>}
          {!connected && <p className="hint-box">Admin tools become active after you connect Supabase. Setup steps are in <code>SETUP.md</code>.</p>}
          <p className="secure-note"><ShieldCheck size={14}/> Only your authenticated account can manage products.</p>
        </> : <>
          <div className="modal-icon"><Upload size={24}/></div><p className="eyebrow">YOUR COLLECTION</p><h2 id="admin-title">{editing ? "Edit product" : "Add a product"}</h2><p className="modal-description">Fields marked with * are required. Upload a clear product photo.</p>
          <form className="admin-form" onSubmit={saveProduct}>
            <label>Product name *<input name="name" required defaultValue={editing?.name || ""} placeholder="e.g. Pearl Drop Earrings"/></label>
            <div className="form-row"><label>Category *<select name="category" defaultValue={editing?.category || "Earrings"}><option>Earrings</option><option>Necklaces</option><option>Other</option></select></label><label>Price (₹) *<input name="price" type="number" min="0" step="1" required defaultValue={editing?.price ?? ""} placeholder="499"/></label></div>
            <label>Product code<input name="code" defaultValue={editing?.code || ""} placeholder="e.g. ER001"/></label>
            <label>Description<textarea name="description" rows="3" defaultValue={editing?.description || ""} placeholder="Short product description"/></label>
            <label className="upload-field"><Upload size={18}/><span>{editing?.image_url ? "Choose a new photo (optional)" : "Upload product photo *"}<small>JPG, PNG or WebP</small></span><input name="photo" type="file" accept="image/*" required={!editing?.image_url}/></label>
            <label className="checkbox-label"><input name="available" type="checkbox" defaultChecked={editing?.available !== false}/> Available to customers</label>
            <button className="primary-button full-button" type="submit">{editing ? "Save changes" : "Add to catalogue"}</button>
            <button className="secondary-button full-button" type="button" onClick={() => setEditing(null)}> {editing ? "Cancel edit" : "Clear form"} </button>
          </form>
          <div className="admin-footer-actions"><span>Signed in as {session.user?.email}</span><button onClick={signOut}>Sign out</button></div>
        </>}
      </section>
    </div>}
  </div>;
}

createRoot(document.getElementById("root")).render(<App />);
